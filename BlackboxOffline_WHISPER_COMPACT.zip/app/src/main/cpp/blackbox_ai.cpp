#include <jni.h>
#include <android/log.h>
#include <string>
#include <thread>
#include "whisper.h"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,"BlackboxAI",__VA_ARGS__)

extern "C" JNIEXPORT jstring JNICALL
Java_com_blackbox_offline_LocalAiEngine_nativeTranscribePcm(JNIEnv *env,jobject,jfloatArray pcm,jstring modelPath){
 const char *path=env->GetStringUTFChars(modelPath,nullptr); whisper_context_params cp=whisper_context_default_params(); cp.use_gpu=false;
 whisper_context *ctx=whisper_init_from_file_with_params(path,cp); env->ReleaseStringUTFChars(modelPath,path);
 if(!ctx)return env->NewStringUTF("Ошибка: не удалось открыть Whisper-модель.");
 jsize n=env->GetArrayLength(pcm); jfloat *audio=env->GetFloatArrayElements(pcm,nullptr);
 whisper_full_params p=whisper_full_default_params(WHISPER_SAMPLING_GREEDY); p.print_progress=false;p.print_realtime=false;p.print_timestamps=false;p.translate=false;p.language="ru";p.no_timestamps=true;p.n_threads=4;
 int rc=whisper_full(ctx,p,audio,n);env->ReleaseFloatArrayElements(pcm,audio,JNI_ABORT);
 if(rc!=0){whisper_free(ctx);return env->NewStringUTF("Ошибка: Whisper не смог обработать запись.");}
 std::string result;for(int i=0;i<whisper_full_n_segments(ctx);i++){const char *s=whisper_full_get_segment_text(ctx,i);if(s)result+=s;}whisper_free(ctx);
 if(result.empty())result="[Речь не распознана]";return env->NewStringUTF(result.c_str());
}
