package com.blackbox.offline;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Intelligent local Whisper transcription pipeline.
 * Features:
 * - Anti-hallucination cleaning
 * - Trash rejection: drops non-speech noise
 * - Voice Stop Keyword detection: stops background recording service
 * - Hands-free Voice Recall: answers questions like "блэкбокс, какой код..." via instant push notification
 */
public final class AutoTranscriber {
    private static final ExecutorService queue = Executors.newSingleThreadExecutor();

    private AutoTranscriber() {}

    public static void enqueue(Context c, Entry e) {
        Context app = c.getApplicationContext();
        queue.execute(() -> {
            try {
                e.status = "Расшифровка…";
                new EntryStore(app).replace(e);

                String rawText = new LocalAiEngine(app).transcribe(e.path);
                String clean = cleanHallucinations(rawText);

                if (clean.length() < 3) {
                    try {
                        if (e.path != null && !e.path.isEmpty()) {
                            new File(e.path).delete();
                        }
                    } catch (Exception ignored) {}
                    new EntryStore(app).delete(e.id);
                    app.sendBroadcast(new Intent(RecordingService.ENTRIES).setPackage(app.getPackageName()));
                    return;
                }

                e.transcript = clean;
                e.status = "Готово";

                String lower = clean.toLowerCase();

                // 1. Voice Stop Commands
                boolean isStopCommand = lower.contains("блэкбокс стоп")
                        || lower.contains("блэкбокс, стоп")
                        || lower.contains("блэкбокс остановись")
                        || lower.contains("блэкбокс, остановись")
                        || lower.contains("блэкбокс отключись")
                        || lower.contains("блэкбокс, отключись")
                        || lower.contains("блэкбокс хватит")
                        || lower.contains("блэкбокс спать")
                        || lower.contains("blackbox stop")
                        || lower.contains("останови запись")
                        || lower.contains("стоп запись");

                if (isStopCommand) {
                    Intent stopIntent = new Intent(app, RecordingService.class).setAction(RecordingService.STOP);
                    app.startService(stopIntent);
                    e.important = true;
                    e.category = "Команды";
                    e.summary = "⏹ Остановлено голосовой командой";
                }

                // 2. Hands-Free Voice Recall ("Блэкбокс, какой...", "Блэкбокс, где...")
                boolean isQuestionToMemory = lower.contains("блэкбокс") && (
                        lower.contains("какой") || lower.contains("где") || lower.contains("когда")
                                || lower.contains("куда") || lower.contains("сколько") || lower.contains("напомни")
                                || lower.contains("пароль") || lower.contains("код") || lower.contains("номер")
                );

                if (isQuestionToMemory && !isStopCommand) {
                    processHandsFreeMemoryRecall(app, clean);
                }

                // 3. Important Flag
                boolean isImportant = lower.contains("блэкбокс важно")
                        || lower.contains("blackbox важно")
                        || lower.contains("запомни это")
                        || lower.contains("очень важно")
                        || lower.contains("важная мысль");

                if (isImportant) {
                    e.important = true;
                    e.summary = "ВАЖНО";
                }

                // 4. Smart Categorization
                if (!isStopCommand) {
                    e.category = detectCategory(lower);
                }

                new EntryStore(app).replace(e);
                app.sendBroadcast(new Intent(RecordingService.ENTRIES).setPackage(app.getPackageName()));
            } catch (Exception x) {
                e.status = "Ошибка: " + (x.getMessage() == null ? "сбой" : x.getMessage());
                new EntryStore(app).replace(e);
                app.sendBroadcast(new Intent(RecordingService.ENTRIES).setPackage(app.getPackageName()));
            }
        });
    }

    private static void processHandsFreeMemoryRecall(Context context, String query) {
        new Thread(() -> {
            try {
                StringBuilder archiveContext = new StringBuilder();
                for (Entry item : new EntryStore(context).all()) {
                    if (item.transcript != null && !item.transcript.trim().isEmpty()) {
                        archiveContext.append("[").append(item.created).append("] ")
                                      .append(item.transcript.trim())
                                      .append("\n\n");
                    }
                }

                LocalAiEngine ai = new LocalAiEngine(context);
                String answer = ai.answer(query, archiveContext.toString());

                // Post Instant Memory Notification to lock screen
                NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null) {
                    Notification n;
                    if (Build.VERSION.SDK_INT >= 26) {
                        n = new Notification.Builder(context, "memory_recall")
                                .setSmallIcon(android.R.drawable.ic_dialog_info)
                                .setContentTitle("Blackbox Память")
                                .setContentText(answer)
                                .setStyle(new Notification.BigTextStyle().bigText(answer))
                                .setAutoCancel(true)
                                .build();
                    } else {
                        n = new Notification.Builder(context)
                                .setSmallIcon(android.R.drawable.ic_dialog_info)
                                .setContentTitle("Blackbox Память")
                                .setContentText(answer)
                                .setAutoCancel(true)
                                .build();
                    }
                    nm.notify(991, n);
                }
            } catch (Throwable ignored) {}
        }).start();
    }

    public static String cleanHallucinations(String raw) {
        if (raw == null) return "";
        String s = raw.replaceAll("\\[[^\\]]*\\]", "").replaceAll("\\([^\\)]*\\)", "");
        s = s.replaceAll("(?i)\\b(музыка|звуки|аплодисменты|смех|шум|пение|помехи|звонок|речь не распознана|спасибо за просмотр|субтитры сделал|продолжение следует)\\b", "");
        s = s.replaceAll("\\s+", " ").trim();
        s = s.replaceAll("^[\\.,\\-\\?!;:\\s]+", "").replaceAll("[\\.,\\-\\?!;:\\s]+$", "").trim();
        return s;
    }

    public static String detectCategory(String lower) {
        if (lower.contains("задач") || lower.contains("сделать") || lower.contains("купить")
                || lower.contains("нужно") || lower.contains("надо") || lower.contains("чеклист")
                || lower.contains("список") || lower.contains("напомни")) {
            return "Задачи";
        }
        if (lower.contains("встреч") || lower.contains("созвон") || lower.contains("звонок")
                || lower.contains("договорил") || lower.contains("планёрк") || lower.contains("митинг")
                || lower.contains("в 1") || lower.contains("в 2") || lower.contains("часов")) {
            return "Встречи";
        }
        if (lower.contains("идея") || lower.contains("придумал") || lower.contains("мысль")
                || lower.contains("проект") || lower.contains("концепт") || lower.contains("гипотез")) {
            return "Идеи";
        }
        return "Заметки";
    }
}
