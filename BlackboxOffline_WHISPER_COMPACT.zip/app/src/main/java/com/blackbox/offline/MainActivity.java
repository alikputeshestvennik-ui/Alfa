package com.blackbox.offline;

import android.animation.ValueAnimator;
import android.media.MediaPlayer;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.os.*;
import android.util.TypedValue;
import android.view.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Flagship Monolith Navigation Controller (Single Activity Architecture).
 * Features:
 * - Ultra-responsive Bottom Navigation Bar with glowing amber active indicator
 * - Brutalist Black Screen with classic Blackbox Monolith Logo button (animated pulse/scale)
 * - Native tabs: [Главная] [История] [Сводка] [Поиск] [Модели]
 * - Direct playback suppression in History
 * - Stealth copyright "alim" in Models view
 */
public class MainActivity extends Activity {
    private FrameLayout contentFrame;
    private ImageView logoView;
    private TextView statusDescView;
    private TextView statusBadgeView;

    // Bottom Bar Icons & Labels
    private ImageView[] tabIcons;
    private LinearLayout[] tabButtons;
    private View[] tabDots;
    private int currentTab = 0; // 0: Home, 1: History, 2: Summary, 3: Search, 4: Models

    private static final int REQ_IMPORT_WHISPER = 101;
    private static final int REQ_IMPORT_LLM = 102;
    private MediaPlayer player;
    private Button playBtn;

    private boolean isRecording = false;

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            isRecording = i.getBooleanExtra("active", isRecording);
            updateHomeUi();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        RetentionManager.clean(this);

        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stateReceiver, new IntentFilter(RecordingService.STATE), Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(stateReceiver, new IntentFilter(RecordingService.STATE));
        }

        renderMainShell();
        switchTab(0);
    }

    private void renderMainShell() {
        RelativeLayout root = new RelativeLayout(this);
        root.setBackgroundColor(0xFF000000); // Obsidian True Black

        // Content Area (Top)
        contentFrame = new FrameLayout(this);
        contentFrame.setId(View.generateViewId());
        RelativeLayout.LayoutParams clp = new RelativeLayout.LayoutParams(-1, -1);
        clp.addRule(RelativeLayout.ALIGN_PARENT_TOP);
        root.addView(contentFrame, clp);

        // Bottom Navigation Bar — Floating Liquid Glass Island (icon-only)
        LinearLayout bottomBar = new LinearLayout(this);
        bottomBar.setId(View.generateViewId());
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.CENTER);

        GradientDrawable glassBg = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xD91C2029, 0xC212141A});
        glassBg.setCornerRadius(dp(28));
        glassBg.setStroke(dp(1), 0x2EFFFFFF); // thin light rim
        bottomBar.setBackground(glassBg);
        bottomBar.setPadding(dp(10), dp(10), dp(10), dp(10));

        RelativeLayout.LayoutParams blp = new RelativeLayout.LayoutParams(-1, dp(60));
        blp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        blp.leftMargin = dp(14);
        blp.rightMargin = dp(14);
        blp.bottomMargin = dp(12);
        root.addView(bottomBar, blp);

        // Make contentFrame sit above bottomBar
        clp.addRule(RelativeLayout.ABOVE, bottomBar.getId());

        // System window insets: content below status bar, bar above nav gestures
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            contentFrame.setPadding(0, insets.getSystemWindowInsetTop(), 0, 0);
            blp.bottomMargin = dp(12) + insets.getSystemWindowInsetBottom();
            bottomBar.setLayoutParams(blp);
            return insets;
        });

        // Setup 5 Bottom Tabs (icons only)
        String[] icons = new String[]{"ic_nav_home", "ic_nav_history", "ic_nav_summary", "ic_nav_search", "ic_nav_models"};

        tabIcons = new ImageView[5];
        tabButtons = new LinearLayout[5];
        tabDots = new View[5];

        for (int i = 0; i < 5; i++) {
            final int tabIndex = i;
            LinearLayout btn = new LinearLayout(this);
            btn.setOrientation(LinearLayout.VERTICAL);
            btn.setGravity(Gravity.CENTER);
            btn.setClickable(true);
            btn.setFocusable(true);

            GradientDrawable rippleMask = new GradientDrawable();
            rippleMask.setCornerRadius(dp(20));
            rippleMask.setColor(0xFFFFFFFF);
            btn.setForeground(new RippleDrawable(
                    ColorStateList.valueOf(0x40F47721), null, rippleMask));

            ImageView iv = new ImageView(this);
            int resId = getResources().getIdentifier(icons[i], "drawable", getPackageName());
            if (resId != 0) iv.setImageResource(resId);
            btn.addView(iv, new LinearLayout.LayoutParams(dp(24), dp(24)));

            View dot = new View(this);
            GradientDrawable dotBg = new GradientDrawable();
            dotBg.setShape(GradientDrawable.OVAL);
            dotBg.setColor(0xFFF47721);
            dot.setBackground(dotBg);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(4), dp(4));
            dlp.topMargin = dp(3);
            btn.addView(dot, dlp);
            dot.setVisibility(View.INVISIBLE);
            tabDots[i] = dot;

            tabIcons[i] = iv;
            tabButtons[i] = btn;
            btn.setOnClickListener(v -> switchTab(tabIndex));
            bottomBar.addView(btn, new LinearLayout.LayoutParams(0, -1, 1.0f));
        }

        setContentView(root);
    }

    private void switchTab(int index) {
        currentTab = index;

        // Update Bottom Bar Highlighting
        for (int i = 0; i < 5; i++) {
            boolean active = (i == index);
            int activeColor = 0xFFF47721; // Solar Amber
            int inactiveColor = 0xFF5D6574; // Matte Dark Slate

            tabIcons[i].setColorFilter(active ? activeColor : inactiveColor);
            tabDots[i].setVisibility(active ? View.VISIBLE : View.INVISIBLE);
        }

        // Render tab content inside contentFrame
        contentFrame.removeAllViews();

        switch (index) {
            case 0:
                renderHomeTab();
                break;
            case 1:
                renderHistoryTab();
                break;
            case 2:
                renderSummaryTab();
                break;
            case 3:
                renderSearchTab();
                break;
            case 4:
                renderModelsTab();
                break;
        }
    }

    // ==========================================
    // TAB 0: HOME SCREEN (BRUTALIST LOGO BUTTON)
    // ==========================================
    private void renderHomeTab() {
        LinearLayout home = new LinearLayout(this);
        home.setOrientation(LinearLayout.VERTICAL);
        home.setGravity(Gravity.CENTER);
        home.setPadding(dp(24), dp(40), dp(24), dp(20));

        TextView brandTitle = new TextView(this);
        brandTitle.setText("BLACKBOX");
        brandTitle.setTextColor(Color.WHITE);
        brandTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        brandTitle.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        brandTitle.setLetterSpacing(0.12f);
        home.addView(brandTitle);

        statusBadgeView = new TextView(this);
        statusBadgeView.setText("АВТОНОМНЫЙ АУДИО-АРХИВ");
        statusBadgeView.setTextColor(0xFF8E95A2);
        statusBadgeView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        statusBadgeView.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        statusBadgeView.setLetterSpacing(0.08f);
        statusBadgeView.setPadding(0, dp(4), 0, 0);
        home.addView(statusBadgeView);

        // Huge interactive animated Logo Button
        FrameLayout logoContainer = new FrameLayout(this);
        int containerSize = dp(170);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(containerSize, containerSize);
        clp.topMargin = dp(60);
        clp.bottomMargin = dp(50);
        logoContainer.setLayoutParams(clp);

        logoView = new ImageView(this);
        logoView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logoView.setClickable(true);
        logoView.setFocusable(true);
        FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(-1, -1);
        logoContainer.addView(logoView, flp);

        logoView.setOnClickListener(v -> toggleRecordingAnimated());
        home.addView(logoContainer);

        statusDescView = new TextView(this);
        statusDescView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        statusDescView.setTextColor(0xFF8E95A2);
        statusDescView.setGravity(Gravity.CENTER);
        statusDescView.setLineSpacing(dp(3), 1.0f);
        home.addView(statusDescView);

        if (!ModelManager.installed(this, ModelManager.WHISPER)) {
            TextView warn = new TextView(this);
            warn.setText("⚠ Whisper не установлен — импортируйте модель во вкладке «Модели»");
            warn.setTextColor(0xFFFFA25F);
            warn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            warn.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(-1, -2);
            wlp.topMargin = dp(14);
            home.addView(warn, wlp);
        }

        contentFrame.addView(home, new FrameLayout.LayoutParams(-1, -1));

        isRecording = RecordingService.isRecordingActive;
        updateHomeUi();
    }

    private void toggleRecordingAnimated() {
        // Animate scale bounce
        ValueAnimator anim = ValueAnimator.ofFloat(1.0f, 0.90f, 1.05f, 1.0f);
        anim.setDuration(350);
        anim.setInterpolator(new AccelerateDecelerateInterpolator());
        anim.addUpdateListener(animation -> {
            float s = (float) animation.getAnimatedValue();
            if (logoView != null) {
                logoView.setScaleX(s);
                logoView.setScaleY(s);
            }
        });
        anim.start();

        if (isRecording) {
            startService(new Intent(this, RecordingService.class).setAction(RecordingService.STOP));
        } else {
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                startRecordingService();
            } else {
                requestPermissions(new String[]{
                        android.Manifest.permission.RECORD_AUDIO,
                        Build.VERSION.SDK_INT >= 33 ? android.Manifest.permission.POST_NOTIFICATIONS : android.Manifest.permission.RECORD_AUDIO
                }, 42);
            }
        }
    }

    private void startRecordingService() {
        Intent i = new Intent(this, RecordingService.class).setAction(RecordingService.START);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }
        isRecording = true;
        updateHomeUi();
    }

    private void updateHomeUi() {
        if (logoView == null || statusDescView == null) return;

        if (isRecording) {
            int logoRes = getResources().getIdentifier("blackbox_mark", "drawable", getPackageName());
            if (logoRes != 0) logoView.setImageResource(logoRes);
            statusBadgeView.setText("● СЛУШАЮ В ФОНЕ");
            statusBadgeView.setTextColor(0xFFEF4444);
            statusDescView.setText("Фоновая запись активна.\nСкажите «Блэкбокс, стоп» для завершения.");
        } else {
            int monoRes = getResources().getIdentifier("blackbox_mark_mono", "drawable", getPackageName());
            if (monoRes != 0) logoView.setImageResource(monoRes);
            statusBadgeView.setText("ЗАПИСЬ ОСТАНОВЛЕНА");
            statusBadgeView.setTextColor(0xFF8E95A2);
            statusDescView.setText("Коснитесь логотипа для включения\nфонового прослушивания.");
        }
    }

    // ==========================================
    // TAB 1: HISTORY (WITH AUDIO GATE ON PLAY)
    // ==========================================
    private void renderHistoryTab() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int padH = dp(18);
        int padV = dp(24);
        content.setPadding(padH, padV, padH, dp(80));

        TextView title = new TextView(this);
        title.setText("История событий");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        content.addView(title);

        ArrayList<Entry> entries = new EntryStore(this).all();

        TextView countView = new TextView(this);
        countView.setText("Всего фрагментов в памяти: " + entries.size());
        countView.setTextColor(0xFF8E95A2);
        countView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        countView.setPadding(0, dp(3), 0, dp(16));
        content.addView(countView);

        if (entries.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("В архиве пока нет записей. Включите запись на главном экране или часах.");
            empty.setTextColor(0xFF5D6574);
            empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            empty.setPadding(0, dp(40), 0, 0);
            content.addView(empty);
        } else {
            for (Entry e : entries) {
                String clean = AutoTranscriber.cleanHallucinations(e.transcript);
                boolean hasText = clean.length() >= 2;

                LinearLayout card = UI.createCard(this);

                LinearLayout meta = new LinearLayout(this);
                meta.setOrientation(LinearLayout.HORIZONTAL);
                meta.setGravity(Gravity.CENTER_VERTICAL);

                TextView timeBadge = UI.badge(this, e.created, 0xFFFFA25F, 0xFF221710);
                meta.addView(timeBadge);

                TextView catBadge = UI.badge(this, e.category, Color.WHITE, 0xFF191D24);
                LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-2, -2);
                clp.leftMargin = dp(8);
                meta.addView(catBadge, clp);

                card.addView(meta);

                TextView tv = new TextView(this);
                if (hasText) {
                    tv.setText(QwenEngine.polishSpokenRussian(clean));
                    tv.setTextColor(0xFFF1F3F7);
                } else {
                    String st = (e.status == null || e.status.isEmpty()) ? "В очереди" : e.status;
                    boolean modelMissing = !ModelManager.installed(this, ModelManager.WHISPER);
                    tv.setText(modelMissing
                            ? st + "\nИмпортируйте модель Whisper во вкладке «Модели», чтобы расшифровка работала."
                            : st);
                    tv.setTextColor(0xFF8E95A2);
                }
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
                tv.setLineSpacing(dp(3), 1.0f);
                tv.setPadding(0, dp(10), 0, dp(12));
                card.addView(tv);

                LinearLayout actRow = new LinearLayout(this);
                actRow.setOrientation(LinearLayout.HORIZONTAL);

                File af = (e.path != null && !e.path.isEmpty()) ? new File(e.path) : null;
                if (af != null && af.isFile()) {
                    Button listenBtn = UI.secondaryButton(this, "Слушать");
                    listenBtn.setOnClickListener(v -> togglePlayback(listenBtn, af));
                    actRow.addView(listenBtn);
                }

                Button copyBtn = UI.secondaryButton(this, "Копировать");
                copyBtn.setOnClickListener(v -> UI.copyToClipboard(this, "Запись", clean));
                actRow.addView(copyBtn);

                Button delBtn = UI.secondaryButton(this, "Удалить");
                delBtn.setTextColor(0xFFEF4444);
                LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-2, -2);
                dlp.leftMargin = dp(8);
                delBtn.setOnClickListener(v -> {
                    new EntryStore(this).delete(e.id);
                    switchTab(1);
                });
                actRow.addView(delBtn, dlp);

                if (!hasText) {
                    Button retryBtn = UI.secondaryButton(this, "Повторить");
                    LinearLayout.LayoutParams rlp2 = new LinearLayout.LayoutParams(-2, -2);
                    rlp2.leftMargin = dp(8);
                    retryBtn.setOnClickListener(v -> {
                        e.status = "В очереди";
                        new EntryStore(this).replace(e);
                        AutoTranscriber.enqueue(this, e);
                        Toast.makeText(this, "Запись снова в очереди на расшифровку", Toast.LENGTH_SHORT).show();
                        switchTab(1);
                    });
                    actRow.addView(retryBtn, rlp2);
                }

                card.addView(actRow);

                LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
                cardLp.bottomMargin = dp(12);
                content.addView(card, cardLp);
            }
        }

        scroll.addView(content);
        contentFrame.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
    }

    // ==========================================
    // TAB 2: SUMMARY (BRUTALIST EXECUTIVE BRIEF)
    // ==========================================
    private void renderSummaryTab() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int padH = dp(18);
        int padV = dp(24);
        content.setPadding(padH, padV, padH, dp(80));

        TextView title = new TextView(this);
        title.setText("Аналитический отчёт");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        content.addView(title);

        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        List<Entry> dayEntries = new ArrayList<>();
        for (Entry e : new EntryStore(this).all()) {
            if (e.created != null && e.created.startsWith(today)
                    && e.transcript != null && !e.transcript.trim().isEmpty()) {
                dayEntries.add(e);
            }
        }

        if (dayEntries.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("За сегодня (" + today + ") пока нет готовых записей для синтеза.");
            empty.setTextColor(0xFF5D6574);
            empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            empty.setPadding(0, dp(30), 0, 0);
            content.addView(empty);
        } else {
            LocalAiEngine ai = new LocalAiEngine(this);
            QwenEngine.DaySummary summary = ai.summarizeDay(dayEntries, today);

            LinearLayout briefCard = UI.createCard(this);
            TextView bTitle = new TextView(this);
            bTitle.setText("ФОКУС ДНЯ");
            bTitle.setTextColor(0xFFFFA25F);
            bTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            bTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            briefCard.addView(bTitle);

            TextView bText = new TextView(this);
            bText.setText(summary.executiveBrief);
            bText.setTextColor(0xFFF1F3F7);
            bText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            bText.setLineSpacing(dp(3), 1.0f);
            bText.setPadding(0, dp(8), 0, 0);
            briefCard.addView(bText);

            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, -2);
            blp.topMargin = dp(14);
            blp.bottomMargin = dp(16);
            content.addView(briefCard, blp);

            // Priorities & Tasks
            renderSummaryList(content, "КЛЮЧЕВЫЕ ЗАДАЧИ", summary.tasks);
            renderSummaryList(content, "ДОГОВОРЁННОСТИ И ВСТРЕЧИ", summary.meetings);
            renderSummaryList(content, "ХРОНИКА", summary.chronicle);
        }

        scroll.addView(content);
        contentFrame.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
    }

    private void renderSummaryList(LinearLayout root, String header, List<QwenEngine.SummaryItem> items) {
        if (items == null || items.isEmpty()) return;

        TextView h = new TextView(this);
        h.setText(header);
        h.setTextColor(0xFF8E95A2);
        h.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        h.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        h.setPadding(dp(4), dp(10), 0, dp(6));
        root.addView(h);

        for (QwenEngine.SummaryItem it : items) {
            LinearLayout itemCard = UI.createCard(this);
            itemCard.setOrientation(LinearLayout.HORIZONTAL);
            itemCard.setGravity(Gravity.CENTER_VERTICAL);
            int pad = dp(12);
            itemCard.setPadding(pad, pad, pad, pad);

            TextView timeView = UI.badge(this, it.time, 0xFFFFA25F, 0xFF221710);
            itemCard.addView(timeView);

            TextView text = new TextView(this);
            text.setText(it.refinedText);
            text.setTextColor(0xFFF1F3F7);
            text.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, -2, 1.0f);
            tlp.leftMargin = dp(10);
            itemCard.addView(text, tlp);

            LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
            cardLp.bottomMargin = dp(8);
            root.addView(itemCard, cardLp);
        }
    }

    // ==========================================
    // TAB 3: SEARCH & NATURAL ASSISTANT
    // ==========================================
    private void renderSearchTab() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int padH = dp(18);
        int padV = dp(24);
        content.setPadding(padH, padV, padH, dp(80));

        TextView title = new TextView(this);
        title.setText("Поиск в памяти");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        content.addView(title);

        EditText input = UI.inputField(this, "Какой код от домофона? О чём говорили?");
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(-1, -2);
        ilp.topMargin = dp(14);
        ilp.bottomMargin = dp(12);
        content.addView(input, ilp);

        TextView resView = new TextView(this);
        resView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        resView.setTextColor(0xFFF1F3F7);
        resView.setLineSpacing(dp(3), 1.0f);
        resView.setPadding(dp(12), dp(16), dp(12), dp(16));
        resView.setBackground(UI.shape(0xFF12141A, 0xFF232733, 14, this));
        resView.setVisibility(View.GONE);

        Button askBtn = UI.primaryButton(this, "Найти в архиве");
        askBtn.setOnClickListener(v -> {
            String q = input.getText().toString().trim();
            if (q.isEmpty()) return;

            StringBuilder archive = new StringBuilder();
            for (Entry e : new EntryStore(this).all()) {
                if (e.transcript != null && !e.transcript.trim().isEmpty()) {
                    archive.append("[").append(e.created).append("] ")
                           .append(e.transcript.trim()).append("\n\n");
                }
            }

            LocalAiEngine ai = new LocalAiEngine(this);
            String ans = ai.answer(q, archive.toString());
            resView.setText(ans);
            resView.setVisibility(View.VISIBLE);
        });
        content.addView(askBtn);

        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, -2);
        rlp.topMargin = dp(16);
        content.addView(resView, rlp);

        scroll.addView(content);
        contentFrame.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
    }

    // ==========================================
    // TAB 4: MODELS & STEALTH COPYRIGHT "ALIM"
    // ==========================================
    private void renderModelsTab() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int padH = dp(18);
        int padV = dp(24);
        content.setPadding(padH, padV, padH, dp(80));

        TextView title = new TextView(this);
        title.setText("Нейросетевые ядра");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        content.addView(title);

        // Whisper Card
        LinearLayout wCard = UI.createCard(this);
        TextView wTitle = new TextView(this);
        wTitle.setText("Whisper Large-v3 Turbo (Speech-to-Text)");
        wTitle.setTextColor(Color.WHITE);
        wTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        wTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        wCard.addView(wTitle);

        boolean whisperInstalled = ModelManager.installed(this, ModelManager.WHISPER);
        TextView wStatus = new TextView(this);
        wStatus.setText("Статус: " + ModelManager.size(this, ModelManager.WHISPER));
        wStatus.setTextColor(0xFFFFA25F);
        wStatus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        wStatus.setPadding(0, dp(6), 0, 0);
        wCard.addView(wStatus);

        if (!whisperInstalled) {
            TextView wWarn = new TextView(this);
            wWarn.setText("Модель не установлена — расшифровка речи невозможна.");
            wWarn.setTextColor(0xFFEF4444);
            wWarn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            wWarn.setPadding(0, dp(6), 0, 0);
            wCard.addView(wWarn);
        }

        Button wImport = UI.primaryButton(this, whisperInstalled ? "Заменить Whisper-модель" : "Импортировать Whisper (.bin)");
        wImport.setOnClickListener(v -> pickModelFile(REQ_IMPORT_WHISPER));
        LinearLayout.LayoutParams wilp = new LinearLayout.LayoutParams(-1, -2);
        wilp.topMargin = dp(12);
        wCard.addView(wImport, wilp);

        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(-1, -2);
        wlp.topMargin = dp(14);
        wlp.bottomMargin = dp(12);
        content.addView(wCard, wlp);

        // Qwen LLM Card
        LinearLayout qCard = UI.createCard(this);
        TextView qTitle = new TextView(this);
        qTitle.setText("Qwen 2.5 Intelligence Core (GGUF)");
        qTitle.setTextColor(Color.WHITE);
        qTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        qTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        qCard.addView(qTitle);

        boolean llmInstalled = ModelManager.installed(this, ModelManager.LLM);
        TextView qStatus = new TextView(this);
        qStatus.setText("Статус: " + ModelManager.size(this, ModelManager.LLM));
        qStatus.setTextColor(0xFFFFA25F);
        qStatus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        qStatus.setPadding(0, dp(6), 0, 0);
        qCard.addView(qStatus);

        Button qImport = UI.secondaryButton(this, llmInstalled ? "Заменить qwen.gguf" : "Импортировать Qwen GGUF");
        qImport.setOnClickListener(v -> pickModelFile(REQ_IMPORT_LLM));
        LinearLayout.LayoutParams qilp = new LinearLayout.LayoutParams(-1, -2);
        qilp.topMargin = dp(12);
        qCard.addView(qImport, qilp);

        LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(-1, -2);
        qlp.bottomMargin = dp(30);
        content.addView(qCard, qlp);

        // Stealth Author Signature: "alim"
        TextView copyright = new TextView(this);
        copyright.setText("SYSTEM CORE 2.4.0-OFFLINE · DESIGNED BY ALIM");
        copyright.setTextColor(0xFF2E333D); // Stealth dark matte grey
        copyright.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        copyright.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        copyright.setLetterSpacing(0.08f);
        copyright.setGravity(Gravity.CENTER);
        content.addView(copyright);

        scroll.addView(content);
        contentFrame.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
    }

    private void pickModelFile(int req) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try {
            startActivityForResult(i, req);
        } catch (Exception e) {
            Toast.makeText(this, "Нет приложения для выбора файла", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        String target;
        if (req == REQ_IMPORT_WHISPER) target = ModelManager.WHISPER;
        else if (req == REQ_IMPORT_LLM) target = ModelManager.LLM;
        else return;

        Uri uri = data.getData();
        Toast.makeText(this, "Копирование весов модели…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                ModelManager.importFile(this, uri, target);
                runOnUiThread(() -> {
                    Toast.makeText(this, "Модель успешно установлена!", Toast.LENGTH_SHORT).show();
                    switchTab(4);
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this,
                        "Ошибка импорта: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void togglePlayback(Button btn, File f) {
        try {
            if (player != null && player.isPlaying()) {
                player.stop();
                player.release();
                player = null;
                resetPlayButtons();
                return;
            }
            resetPlayButtons();
            player = new MediaPlayer();
            player.setDataSource(f.getAbsolutePath());
            player.setOnCompletionListener(mp -> {
                mp.release();
                player = null;
                resetPlayButtons();
            });
            player.setOnErrorListener((mp, what, extra) -> {
                try { mp.release(); } catch (Exception ignored) {}
                player = null;
                resetPlayButtons();
                Toast.makeText(this, "Не удалось воспроизвести запись", Toast.LENGTH_SHORT).show();
                return true;
            });
            player.prepare();
            player.start();
            playBtn = btn;
            btn.setText("■ Стоп");
        } catch (Exception ex) {
            try { if (player != null) player.release(); } catch (Exception ignored) {}
            player = null;
            Toast.makeText(this, "Не удалось воспроизвести запись", Toast.LENGTH_SHORT).show();
        }
    }

    private void resetPlayButtons() {
        if (contentFrame == null) return;
        java.util.ArrayList<Button> found = new java.util.ArrayList<>();
        java.util.ArrayDeque<android.view.View> stack = new java.util.ArrayDeque<>();
        stack.add(contentFrame);
        while (!stack.isEmpty()) {
            android.view.View v = stack.poll();
            if (v instanceof Button) {
                CharSequence cs = ((Button) v).getText();
                if (cs != null && ("■ Стоп".contentEquals(cs) || "Слушать".contentEquals(cs))) {
                    found.add((Button) v);
                }
            } else if (v instanceof android.view.ViewGroup) {
                android.view.ViewGroup g = (android.view.ViewGroup) v;
                for (int i = 0; i < g.getChildCount(); i++) stack.add(g.getChildAt(i));
            }
        }
        for (Button b : found) b.setText("Слушать");
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null) {
            try { player.stop(); player.release(); } catch (Exception ignored) {}
            player = null;
            resetPlayButtons();
        }
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override
    protected void onDestroy() {
        try { unregisterReceiver(stateReceiver); } catch (Throwable ignored) {}
        super.onDestroy();
    }
}
