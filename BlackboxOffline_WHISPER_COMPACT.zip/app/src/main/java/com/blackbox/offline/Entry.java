package com.blackbox.offline;

import org.json.JSONException;
import org.json.JSONObject;

public class Entry {
    public String id;
    public String path;
    public String created;
    public String transcript;
    public String summary;
    public String status;
    public String category;
    public long duration;
    public boolean important;

    public Entry(String id, String path, String created, long duration, String transcript, String summary) {
        this(id, path, created, duration, transcript, summary, "Общее");
    }

    public Entry(String id, String path, String created, long duration, String transcript, String summary, String category) {
        this.id = id;
        this.path = path;
        this.created = created;
        this.duration = duration;
        this.transcript = transcript != null ? transcript : "";
        this.summary = summary != null ? summary : "";
        this.status = this.transcript.isEmpty() ? "В очереди" : "Готово";
        this.category = (category != null && !category.isEmpty()) ? category : "Общее";
        this.important = false;
    }

    public JSONObject json() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("path", path);
        o.put("created", created);
        o.put("duration", duration);
        o.put("transcript", transcript);
        o.put("summary", summary);
        o.put("important", important);
        o.put("status", status);
        o.put("category", category);
        return o;
    }

    public static Entry from(JSONObject o) {
        Entry e = new Entry(
                o.optString("id"),
                o.optString("path"),
                o.optString("created"),
                o.optLong("duration"),
                o.optString("transcript"),
                o.optString("summary"),
                o.optString("category", "Общее")
        );
        e.important = o.optBoolean("important", false);
        e.status = o.optString("status", e.transcript.isEmpty() ? "В очереди" : "Готово");
        return e;
    }
}
