BLACKBOX OFFLINE — Whisper stage 1.2.0

ЧТО РАБОТАЕТ В ЭТОЙ ВЕРСИИ
• Локальная запись AAC/M4A.
• Импорт внешней GGML-модели Whisper через экран «AI-модели».
• Реальная цепочка без интернета: M4A → Android MediaCodec → PCM 16 кГц mono → whisper.cpp → текст.
• В «Истории событий» есть кнопка «Расшифровать». Текст сохраняется у исходной записи на устройстве.
• Для расшифровки достаточно модели Whisper; Qwen не требуется.
• В AndroidManifest нет разрешения INTERNET, в коде нет HTTP-клиента или облачного API.

СБОРКА В CODEASSIST
1. Распакуй ZIP как Gradle-проект.
2. Установи Android NDK (Side by side) и CMake 3.22.1 через SDK Manager CodeAssist.
3. Выполни Gradle Sync и собери APK. ABI ограничен arm64-v8a — это современные 64-битные Android-телефоны.
4. После установки открой «AI-модели», выбери свой ggml-small.bin (или совместимую GGML Whisper-модель) из Downloads и импортируй его.
5. Создай короткую запись → «История событий» → «Расшифровать».

ВАЖНО
• Модель не вложена ни в ZIP, ни в APK: она остаётся твоим локальным файлом и копируется в приватное хранилище приложения как models/whisper.bin.
• Native-сборка whisper.cpp при первом запуске Gradle будет идти существенно дольше обычной Java-сборки.
• Расшифровка выполняется на CPU телефона. Пока показывается диалог обработки, не закрывай приложение.
• Язык Whisper в этой сборке задан как русский (ru).

ЧТО СОЗНАТЕЛЬНО НЕ ВЫДАЁТСЯ ЗА ГОТОВОЕ
Qwen/llama.cpp для саммари и вопросов к дневнику пока не подключён. Соответствующие функции честно сообщают, что это следующий этап, и не возвращают фиктивные ответы.

СОСТАВ НАТИВНОГО СЛОЯ
app/src/main/cpp/third_party/whisper.cpp/ — исходники whisper.cpp (MIT)
app/src/main/cpp/CMakeLists.txt — Android CMake-конфигурация
app/src/main/cpp/blackbox_ai.cpp — JNI-мост
app/src/main/java/com/blackbox/offline/PcmDecoder.java — локальное декодирование M4A/AAC в PCM
app/src/main/java/com/blackbox/offline/LocalAiEngine.java — Java-мост

КОМПАКТНАЯ ПОСТАВКА
Из исходников whisper.cpp удалены только примеры, тесты, тестовые модели, bindings и backend'ы, не используемые в этой Android CPU arm64-v8a сборке. Рабочие CPU-исходники, CMake и лицензия MIT сохранены.
